"use client";

import { useState } from "react";

export default function ContactForm({ locale = "de" as "de" | "en" }) {
  const t = (de: string, en: string) => (locale === "de" ? de : en);

  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setLoading(true);
    setDone(null);
    setErr(null);

    const f = e.currentTarget;
    const data = {
      name: (f.elements.namedItem("name") as HTMLInputElement)?.value || "",
      email: (f.elements.namedItem("email") as HTMLInputElement)?.value || "",
      message: (f.elements.namedItem("message") as HTMLTextAreaElement)?.value || "",
      licht: (f.elements.namedItem("licht") as HTMLInputElement)?.checked || false,
    };

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(data),
      });
      if (!res.ok) throw new Error(await res.text());
      setDone(t("Danke. Wir melden uns in Ruhe.", "Thanks. We’ll get back calmly."));
      f.reset();
    } catch (e) {
      setErr(
        t(
          "Senden fehlgeschlagen. Bitte schreib direkt an contact@saimor.world.",
          "Sending failed. Please email contact@saimor.world."
        )
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className="s-card p-6 md:p-8 max-w-2xl">
      <div className="grid gap-4">
        <label className="grid gap-2">
          <span className="text-sm text-[color:var(--ink)]">{t("Name", "Name")}</span>
          <input
            name="name"
            type="text"
            autoComplete="name"
            className="rounded-xl bg-transparent border border-white/15 px-3 py-2 outline-none focus:border-[color:var(--gold)]"
          />
        </label>

        <label className="grid gap-2">
          <span className="text-sm text-[color:var(--ink)]">E-Mail</span>
          <input
            name="email"
            type="email"
            required
            autoComplete="email"
            className="rounded-xl bg-transparent border border-white/15 px-3 py-2 outline-none focus:border-[color:var(--gold)]"
          />
        </label>

        <label className="grid gap-2">
          <span className="text-sm text-[color:var(--ink)]">{t("Nachricht", "Message")}</span>
          <textarea
            name="message"
            required
            rows={5}
            className="rounded-xl bg-transparent border border-white/15 px-3 py-2 outline-none focus:border-[color:var(--gold)]"
          />
        </label>

        <label className="inline-flex items-center gap-2 select-none">
          <input name="licht" type="checkbox" className="accent-[color:var(--gold)] h-4 w-4" />
          <span className="text-sm">{t("Lichtgespräch anfragen", "Request intro call")}</span>
        </label>

        <div className="flex items-center gap-4 pt-2">
          <button
            disabled={loading}
            className="rounded-2xl border px-5 py-2.5 text-sm font-medium transition
                       hover:bg-[color:var(--gold)] hover:text-[color:var(--navy)]
                       disabled:opacity-60 disabled:cursor-not-allowed"
            style={{ borderColor: "var(--gold)", color: "var(--gold)" }}
          >
            {loading ? t("Senden…", "Sending…") : t("Nachricht senden", "Send message")}
          </button>
          <a
            href={locale === "de" ? "https://cal.com/DEIN-SLUG/lichtgespraech" : "https://cal.com/DEIN-SLUG/intro"}
            target="_blank"
            rel="noreferrer"
            className="text-sm hover:underline underline-offset-4"
            style={{ color: "var(--ink)" }}
          >
            {t("Lichtgespräch buchen", "Book intro call")}
          </a>
        </div>

        <p className="text-xs text-[color:var(--ink)]/80">
          {t(
            "Hinweis: Wir speichern keine Profile, die Nachricht wird nur als E-Mail an uns zugestellt.",
            "Note: No profiling. Your message is only sent to us by email."
          )}
        </p>

        {done && <p className="text-sm text-emerald-300">{done}</p>}
        {err && <p className="text-sm text-rose-300">{err}</p>}
      </div>
    </form>
  );
}
