export const runtime = 'nodejs';

type MailBody = { name?: string; email?: string; message?: string; licht?: boolean };

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as MailBody;
    if (!body?.email || !body?.message) {
      return new Response('E-Mail und Nachricht sind Pflicht.', { status: 400 });
    }

    const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM, CONTACT_TO } = process.env;
    if (!SMTP_HOST || !SMTP_PORT || !SMTP_FROM || !CONTACT_TO) {
      console.warn('[Mail disabled] Missing SMTP envs.');
      return new Response('Formular empfangen (Mail aktuell deaktiviert).', { status: 200 });
    }

    const nodemailer = await import('nodemailer');
    const transporter = nodemailer.createTransport({
      host: SMTP_HOST,
      port: Number(SMTP_PORT),
      secure: Number(SMTP_PORT) === 465,
      auth: SMTP_USER && SMTP_PASS ? { user: SMTP_USER, pass: SMTP_PASS } : undefined,
    });

    const subject = `Saimôr Kontakt${body.licht ? ' • Lichtgespräch' : ''}`;
    const text = `Von: ${body.name ?? 'Unbekannt'} <${body.email}>
Anliegen: ${body.licht ? 'Lichtgespräch' : 'Allgemein'}

Nachricht:
${body.message}`;

    await transporter.sendMail({ from: SMTP_FROM, to: CONTACT_TO, replyTo: body.email, subject, text });
    return new Response('OK', { status: 200 });
  } catch (e) {
    console.error('[contact] error', e);
    return new Response('Fehler beim Senden.', { status: 500 });
  }
}
